<!DOCTYPE qgis PUBLIC 'http://mrcc.com/qgis.dtd' 'SYSTEM'>
<qgis version="3.2.1-Bonn" minScale="1e+8" maxScale="0" hasScaleBasedVisibilityFlag="0">
  <pipe>
    <rasterrenderer classificationMin="5.144e-12" band="1" type="singlebandpseudocolor" classificationMax="1.00207e-5" alphaBand="-1" opacity="1">
      <rasterTransparency/>
      <minMaxOrigin>
        <limits>MinMax</limits>
        <extent>WholeRaster</extent>
        <statAccuracy>Estimated</statAccuracy>
        <cumulativeCutLower>0.02</cumulativeCutLower>
        <cumulativeCutUpper>0.98</cumulativeCutUpper>
        <stdDevFactor>2</stdDevFactor>
      </minMaxOrigin>
      <rastershader>
        <colorrampshader classificationMode="2" clip="0" colorRampType="INTERPOLATED">
          <colorramp type="gradient" name="[source]">
            <prop v="43,131,186,255" k="color1"/>
            <prop v="215,25,28,255" k="color2"/>
            <prop v="0" k="discrete"/>
            <prop v="gradient" k="rampType"/>
            <prop v="0.25;171,221,164,255:0.5;255,255,191,255:0.75;253,174,97,255" k="stops"/>
          </colorramp>
          <item label="5.14e-12" alpha="255" value="5.144e-12" color="#2b83ba"/>
          <item label="1.67e-6" alpha="255" value="1.67012095333333e-6" color="#80bfac"/>
          <item label="3.34e-6" alpha="255" value="3.34023676266667e-6" color="#c7e9ad"/>
          <item label="5.01e-6" alpha="255" value="5.010352572e-6" color="#ffffbf"/>
          <item label="6.68e-6" alpha="255" value="6.68046838133333e-6" color="#fec980"/>
          <item label="8.35e-6" alpha="255" value="8.35058419066667e-6" color="#f17c4a"/>
          <item label="1e-5" alpha="255" value="1.00207e-5" color="#d7191c"/>
        </colorrampshader>
      </rastershader>
    </rasterrenderer>
    <brightnesscontrast contrast="0" brightness="0"/>
    <huesaturation saturation="0" colorizeStrength="100" colorizeGreen="128" colorizeOn="0" colorizeRed="255" grayscaleMode="0" colorizeBlue="128"/>
    <rasterresampler maxOversampling="2"/>
  </pipe>
  <blendMode>0</blendMode>
</qgis>
