<!DOCTYPE qgis PUBLIC 'http://mrcc.com/qgis.dtd' 'SYSTEM'>
<qgis version="3.2.1-Bonn" minScale="1e+8" maxScale="0" hasScaleBasedVisibilityFlag="0">
  <pipe>
    <rasterrenderer classificationMin="0.00011681" band="1" type="singlebandpseudocolor" classificationMax="0.00678862" alphaBand="-1" opacity="1">
      <rasterTransparency/>
      <minMaxOrigin>
        <limits>MinMax</limits>
        <extent>WholeRaster</extent>
        <statAccuracy>Estimated</statAccuracy>
        <cumulativeCutLower>0.02</cumulativeCutLower>
        <cumulativeCutUpper>0.98</cumulativeCutUpper>
        <stdDevFactor>2</stdDevFactor>
      </minMaxOrigin>
      <rastershader>
        <colorrampshader classificationMode="2" clip="0" colorRampType="INTERPOLATED">
          <colorramp type="gradient" name="[source]">
            <prop v="43,131,186,255" k="color1"/>
            <prop v="215,25,28,255" k="color2"/>
            <prop v="0" k="discrete"/>
            <prop v="gradient" k="rampType"/>
            <prop v="0.25;171,221,164,255:0.5;255,255,191,255:0.75;253,174,97,255" k="stops"/>
          </colorramp>
          <item label="0.000117" alpha="255" value="0.00011681" color="#2b83ba"/>
          <item label="0.000858" alpha="255" value="0.000858122222222222" color="#64abb0"/>
          <item label="0.0016" alpha="255" value="0.00159943444444444" color="#9dd3a7"/>
          <item label="0.00234" alpha="255" value="0.00234074666666667" color="#c7e9ad"/>
          <item label="0.00308" alpha="255" value="0.00308205888888889" color="#edf8b9"/>
          <item label="0.00382" alpha="255" value="0.00382337111111111" color="#ffedaa"/>
          <item label="0.00456" alpha="255" value="0.00456468333333333" color="#fec980"/>
          <item label="0.00531" alpha="255" value="0.00530599555555556" color="#f99e59"/>
          <item label="0.00605" alpha="255" value="0.00604730777777778" color="#e85b3a"/>
          <item label="0.00679" alpha="255" value="0.00678862" color="#d7191c"/>
        </colorrampshader>
      </rastershader>
    </rasterrenderer>
    <brightnesscontrast contrast="0" brightness="0"/>
    <huesaturation saturation="0" colorizeStrength="100" colorizeGreen="128" colorizeOn="0" colorizeRed="255" grayscaleMode="0" colorizeBlue="128"/>
    <rasterresampler maxOversampling="2"/>
  </pipe>
  <blendMode>0</blendMode>
</qgis>
